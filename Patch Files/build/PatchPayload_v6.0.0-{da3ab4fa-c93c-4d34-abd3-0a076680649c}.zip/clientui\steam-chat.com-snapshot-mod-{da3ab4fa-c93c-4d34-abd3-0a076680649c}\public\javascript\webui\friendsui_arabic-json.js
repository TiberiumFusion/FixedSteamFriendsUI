﻿










/**** (c) Valve Corporation. Use is governed by the terms of the Steam Subscriber Agreement http://store.steampowered.com/subscriber_agreement/. 
****/
"use strict";(self.webpackChunk_steam_friendsui=self.webpackChunk_steam_friendsui||[]).push([[6518],{83784:e=>{e.exports=JSON.parse('{"language":"arabic"}')}}]);