﻿










/**** (c) Valve Corporation. Use is governed by the terms of the Steam Subscriber Agreement http://store.steampowered.com/subscriber_agreement/. 
****/
"use strict";(self.webpackChunk_steam_friendsui=self.webpackChunk_steam_friendsui||[]).push([[6992],{58480:e=>{e.exports=JSON.parse('{"language":"arabic"}')}}]);