﻿










/**** (c) Valve Corporation. Use is governed by the terms of the Steam Subscriber Agreement http://store.steampowered.com/subscriber_agreement/. 
****/
(self.webpackChunk_steam_friendsui=self.webpackChunk_steam_friendsui||[]).push([[461],{80461:()=>{}}]);